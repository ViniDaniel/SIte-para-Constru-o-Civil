//Esta função formata o CPF para o padrão brasileiro XXX.XXX.XXX-XX.
function formatarCPF(cpf) {
    cpf = cpf.replace(/\D/g, ''); // Remove todos os caracteres não numéricos
    cpf = cpf.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, '$1.$2.$3-$4'); // Formata o CPF
    return cpf;
}

//Esta função valida se o CPF fornecido é válido.
function validarCPF(cpf) {
    cpf = cpf.replace(/\D/g,'');
    if(cpf == '') return false;
    // Elimina CPFs inválidos conhecidos
    if (cpf.length !== 11 ||
        cpf === "00000000000" ||
        cpf === "11111111111" ||
        cpf === "22222222222" ||
        cpf === "33333333333" ||
        cpf === "44444444444" ||
        cpf === "55555555555" ||
        cpf === "66666666666" ||
        cpf === "77777777777" ||
        cpf === "88888888888" ||
        cpf === "99999999999")
        return false;
    // Valida 1º dígito
    let soma = 0;
    for (let i = 0; i < 9; i++)
        soma += parseInt(cpf.charAt(i)) * (10 - i);
    let resto = 11 - (soma % 11);
    if (resto === 10 || resto === 11)
        resto = 0;
    if (resto !== parseInt(cpf.charAt(9)))
        return false;
    // Valida 2º dígito
    soma = 0;
    for (let i = 0; i < 10; i++)
        soma += parseInt(cpf.charAt(i)) * (11 - i);
    resto = 11 - (soma % 11);
    if (resto === 10 || resto === 11)
        resto = 0;
    if (resto !== parseInt(cpf.charAt(10)))
        return false;
    return true;
}

//Esta função verifica se as duas senhas inseridas são iguais. Há também essa função no back_end para maior segurança
function validarSenha() {
  var senha = document.getElementById('senha').value;
  var confirmar_senha = document.getElementById('confirmar_senha').value;
  var mensagemErro = document.getElementById('mensagemErro');

  if (senha !== confirmar_senha) {
      mensagemErro.textContent = 'As senhas não coincidem.';
  } else {
      mensagemErro.textContent = '';
  }
}

//valida se o campo nome está ou não vazio
function validarNome(nome) {
  return nome.trim() !== '';
}

//Esta função verifica se o e-mail tem um formato válido usando uma expressão regular.
function validarEmail(email) {
  const emailRegex = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/; 
  return emailRegex.test(email); 
}


//Esta função verifica se o celular tem 11 dígitos (formato brasileiro).
function validarCelular(celular) {
  const celularLimpo = celular.replace(/\D/g, ''); // Remove todos os caracteres não numéricos
  const celularRegex = /^\d{11}$/; 

  return celularRegex.test(celularLimpo); 
}


console.log(validarCelular('12345678901')); // true
console.log(validarCelular('(12) 34567-8901')); // true
console.log(validarCelular('12 34567 8901')); // true
console.log(validarCelular('123-456-78901')); // true
console.log(validarCelular('1234567890')); // false (apenas 10 dígitos)
console.log(validarCelular('123456789012')); // false (mais de 11 dígitos)


//O mesno q a function validarNome
function validarEndereco(endereco) {
  return endereco.trim() !== '';
}

//O mesno q a function validarNome
function validarBairro(bairro) {
  return bairro.trim() !== '';
}

//O mesno q a function validarNome
function validarCidade(cidade) {
  return cidade.trim() !== '';
}

//Esta função verifica se a sigla do estado (UF) é válida.
function validarUF(uf) {
  const estadosValidos = [
    'AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN', 'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO'
]; 
  return estadosValidos.includes(uf);
}


//Esta função verifica se um radio button foi selecionado.
function validarRadio(nomeRadio) {
  const radios = document.getElementsByName(nomeRadio);
  let selecionado = false; 
  
  for (const radio of radios) {
      if (radio.checked) {
          selecionado = true;
          break;
      }
  }
  
  return selecionado;
}

document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('cadastroForm').addEventListener('submit', function(event) {
      event.preventDefault(); // Impede o envio padrão do formulário

      if (validarFormulario()) {
          const sexo = document.querySelector('input[name="sexo"]:checked').value;
          const sexoFinal = (sexo === 'outro') ? document.getElementById('outroInput').value.trim() : sexo;

          const dados = {
              cpf: document.getElementById('cpf').value.replace(/\D/g, ''),
              nome: document.getElementById('nome').value,
              cep: document.getElementById('cep').value || '',
              endereco: document.getElementById('endereco').value,
              numero_da_casa: document.getElementById('numero_da_casa').value || '',
              bairro: document.getElementById('bairro').value,
              cidade: document.getElementById('cidade').value,
              uf: document.getElementById('uf').value,
              complemento: document.getElementById('complemento').value || '',
              sexo: sexoFinal,
              celular: document.getElementById('celular').value.replace(/\D/g, ''),
              email: document.getElementById('email').value,
              senha: document.getElementById('senha').value,
              confirmar_senha: document.getElementById('confirmar_senha').value
          };

          enviarDados(dados);
      }
  });
});


//Esta função mostra ou esconde o campo de texto "Outro" para o sexo, dependendo da seleção do radio button "Outro".
function toggleOutroInput() {
  const outroInput = document.getElementById('outroInput');
  const outroRadio = document.querySelector('input[name="sexo"][value="outro"]');

  if (outroRadio.checked) {
      outroInput.style.display = 'block';
  } else {
      outroInput.style.display = 'none';
  }
}

function enviarDados(dados) {
  fetch('/cadastro_cliente', {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json'
      },
      body: JSON.stringify(dados)
  })
  .then(response => response.json())
  .then(data => {
      if (data.success) {
          alert(data.message);
          window.location.href = '/login_cliente.html';
      } else {
          throw new Error(data.message);
      }
  })
  .catch(erro => {
      console.error('Erro ao cadastrar usuário:', erro);
      alert('Erro ao cadastrar usuário: ' + erro.message);
  });
}


function validarFormulario() {
  let cpf = document.getElementById("cpf").value;
  cpf = cpf.replace(/\D/g, ''); // Remove caracteres não numéricos
  if (!validarCPF(cpf)) {
      alert("CPF inválido! Por favor, digite um CPF válido.");
      return false;
  }
  var senha = document.getElementById('senha').value;
  var confirmar_senha = document.getElementById('confirmar_senha').value;

  // Verifica se as senhas coincidem
  if (senha !== confirmar_senha) {
      alert('As senhas não coincidem.');
      return false;
  }

  // Verifica se a senha tem pelo menos 6 caracteres
  if (senha.length < 6) {
      alert('A senha deve ter pelo menos 6 caracteres.');
      return false;
  }  
  
  var nome = document.getElementById('nome').value; // Pegando o valor do campo Nome
  if (!validarNome(nome)) {
      alert('O nome não pode estar vazio.'); // Mensagem de erro se o nome está vazio, o mesmo vale para a maioria abaixo
      return false;
  }

  // Validação de e-mail
  var email = document.getElementById('email').value; 
  if (!validarEmail(email)) {
      alert('E-mail inválido! Insira um e-mail válido.');
      return false;
  }

  var celular = document.getElementById('celular').value; 
  if (!validarCelular(celular)) {
      alert('Celular inválido! Insira um celular no formato (xx) xxxxx-xxxx.');
      return false;
  }

  var endereco = document.getElementById('endereco').value;
  if (!validarEndereco(endereco)) {
      alert('O campo de endereço precisa estar preenchido!');
      return false;
  }

  var bairro = document.getElementById('bairro').value;
  if (!validarBairro(bairro)) {
      alert('O campo Bairro deve ser preenchido!');
      return false;
  }

  var cidade = document.getElementById('cidade').value;
  if (!validarCidade(cidade)) {
      alert('O campo Cidade deve ser preenchido!');
      return false;
  }

  var uf = document.getElementById('uf').value
  if (!validarUF(uf)) {
      alert('Selecione uma das opções de Estado!');
      return false;
  }

  if (!validarRadio('sexo')) {
      alert('Por favor, selecione uma opção de sexo.'); 
      return false; // Impede o envio se nenhum radio for selecionado
  }

  const outroInput = document.getElementById('outroInput');
  const outroRadio = document.querySelector('input[name="sexo"][value="outro"]');
  let sexo = document.querySelector('input[name="sexo"]:checked').value;

  if (outroRadio.checked) {
      sexo = outroInput.value.trim();
      if (sexo === '') {
          alert('Por favor, insira o sexo se você selecionou "Outro".');
          return false;
      }
  }

  return true; // Retorne true se a validação passar, caso contrário, false
}

function mascaraCPF() {
    let cpf = document.getElementById("cpf");
    cpf.value = formatarCPF(cpf.value);
}

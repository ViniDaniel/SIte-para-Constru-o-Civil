document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita o envio do formulário padrão

    let cpf = document.getElementById('cpf_cliente').value;
    const senha = document.getElementById('senha').value;

    // Remover pontos e traços do CPF
    cpf = cpf.replace(/[.\-]/g, '');

    // Enviar dados para o servidor
    fetch('/login_cliente', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ cpf, senha })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Armazena o nome do cliente no localStorage
            localStorage.setItem('clienteNome', data.nome);
            // Redirecionar para a página home.html após login bem-sucedido
            window.location.href = "/home.html";
        } else {
            throw new Error('Credenciais inválidas');
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        alert('Credenciais inválidas');
    });
});


/*
Criado para vincular com o arquivo login_cliente, fazer as autenticações no banco de dados e logar nosso usuario
localStorage serve para armazenar o nome do usuário e depois usá-lo para logar o mesmo
*/
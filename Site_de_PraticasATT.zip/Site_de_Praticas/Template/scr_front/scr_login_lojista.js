document.getElementById('loginFormLojista').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita o envio do formulário padrão

    const cnpj = document.getElementById('cnpj_lojista').value;
    const senha = document.getElementById('senha_lojista').value;

    // Enviar dados para o servidor
    fetch('/login_lojista', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ cnpj, senha })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Armazena o nome do lojista no localStorage
            localStorage.setItem('lojistaNome', data.nome); 
            // Redirecionar para a página home.html após login bem-sucedido
            window.location.href = "/home.html";
        } else {
            throw new Error(data.message || 'Credenciais inválidas');
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        alert('Credenciais inválidas');
    });
});


/*
Criado para vincular com o arquivo login_lojista, fazer as autenticações no banco de dados e logar nosso usuario
localStorage serve para armazenar o nome do usuário e depois usá-lo para logar o mesmo
*/
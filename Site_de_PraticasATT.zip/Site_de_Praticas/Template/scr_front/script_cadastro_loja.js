//Esta função verifica se um CNPJ (Cadastro Nacional da Pessoa Jurídica) fornecido é válido.

function validarCNPJ(cnpj) {
    cnpj = cnpj.replace(/\D/g, '');
    if (cnpj == '') return false;
    // Elimina CNPJs inválidos conhecidos
    if (cnpj.length !== 14 ||
        cnpj === "00000000000000" ||
        cnpj === "11111111111111" ||
        cnpj === "22222222222222" ||
        cnpj === "33333333333333" ||
        cnpj === "44444444444444" ||
        cnpj === "55555555555555" ||
        cnpj === "66666666666666" ||
        cnpj === "77777777777777" ||
        cnpj === "88888888888888" ||
        cnpj === "99999999999999")
        return false;
    // Valida 1º dígito
    let soma = 0;
    let peso = 2;
    for (let i = 11; i >= 0; i--) {
        soma += parseInt(cnpj.charAt(i)) * peso;
        peso = peso === 9 ? 2 : peso + 1;
    }
    let resto = soma % 11 < 2 ? 0 : 11 - (soma % 11);
    if (resto !== parseInt(cnpj.charAt(12))) return false;
    // Valida 2º dígito
    soma = 0;
    peso = 2;
    for (let i = 12; i >= 0; i--) {
        soma += parseInt(cnpj.charAt(i)) * peso;
        peso = peso === 9 ? 2 : peso + 1;
    }
    resto = soma % 11 < 2 ? 0 : 11 - (soma % 11);
    if (resto !== parseInt(cnpj.charAt(13))) return false;
    return true;
}

//faz a validação de senha e confirmação, a o mesmo sistema no back_end, usado por segurança
function validarSenha() {
    var senha = document.getElementById('senha').value;
    var confirmar_senha = document.getElementById('confirmar_senha').value;
    var mensagemErro = document.getElementById('mensagemErro');
  
    if (senha !== confirmar_senha) {
        mensagemErro.textContent = 'As senhas não coincidem.';
    } else {
        mensagemErro.textContent = '';
    }
  }


  //valida para o campo não ficar vazio
function validarLoja(nome_da_loja) {
    return nome_da_loja.trim() !== '';
}

//valida para o campo não ficar vazio
function validarEndereco(endereco) {
    return endereco.trim() !== '';
}

//valida para o campo não ficar vazio
function validarBairro(bairro) {
    return bairro.trim() !== '';
}

//valida para o campo não ficar vazio
function validarCidade(cidade) {
    return cidade.trim() !== '';
}


function validarUF(uf) {
    const estadosValidos = [
      'AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN', 'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO'
  ]; 
    return estadosValidos.includes(uf);
  }

  //Esta função verifica se o e-mail tem um formato válido usando uma expressão regular.
  function validarEmail(email) {
    const emailRegex = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/; 
    return emailRegex.test(email); 
  }
  
  //Esta função verifica se o celular tem 11 dígitos (formato brasileiro).
  function validarCelular(celular) {
    const celularLimpo = celular.replace(/\D/g, ''); // Remove todos os caracteres não numéricos
    const celularRegex = /^\d{11}$/; 
  
    return celularRegex.test(celularLimpo); 
  }
  
  
  console.log(validarCelular('12345678901')); // true
  console.log(validarCelular('(12) 34567-8901')); // true
  console.log(validarCelular('12 34567 8901')); // true
  console.log(validarCelular('123-456-78901')); // true
  console.log(validarCelular('1234567890')); // false (apenas 10 dígitos)
  console.log(validarCelular('123456789012')); // false (mais de 11 dígitos)

  //verifica qual o estilo da loja, para organizarmos melhor as preferencias do cliente
  function validarTipo_Loja() {
    const tipo_loja = document.getElementById('tipo_loja').value;

    if (tipo_loja === "" || tipo_loja === null) {
        return false;
    }

    return true;
}

//EXIGE ALGUMA COISA NO CAMPO DE AMBIÇÕES
  function validarAmbicoes(ambicoes){
    return ambicoes.trim() !== '';
  }

  document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('cadastroForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Impede o envio padrão do formulário

        if (validarFormulario()) {

            const dados = {
                cnpj: document.getElementById('cnpj').value.replace(/\D/g, ''),
                inscricao_estadual: document.getElementById('inscricao_estadual').value || '',
                nome_da_loja: document.getElementById('nome_da_loja').value,
                cep: document.getElementById('cep').value || '',
                endereco: document.getElementById('endereco').value,
                numero_da_loja: document.getElementById('numero_da_loja').value || '',
                bairro: document.getElementById('bairro').value,
                cidade: document.getElementById('cidade').value,
                uf: document.getElementById('uf').value,
                complemento: document.getElementById('complemento').value || '',
                celular: document.getElementById('celular').value.replace(/\D/g, ''),
                telefone: document.getElementById('telefone').value || '',
                email: document.getElementById('email').value,
                tipo_loja: document.getElementById('tipo_loja').value,
                ambicoes: document.getElementById('ambicoes').value,
                senha: document.getElementById('senha').value,
                confirmar_senha: document.getElementById('confirmar_senha').value
            };

            enviarDados(dados);
        }
    });
});

function enviarDados(dados) {
    fetch('/cadastro_lojista', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(dados)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(data.message);
            window.location.href = '/login_colaborador.html';
        } else {
            throw new Error(data.message);
        }
    })
    .catch(erro => {
        console.error('Erro ao cadastrar loja:', erro);
        alert('Erro ao cadastrar loja: ' + erro.message);
    });
}
  

function validarFormulario() {
    let cnpj = document.getElementById("cnpj").value;
    cnpj = cnpj.replace(/\D/g, ''); // Remove caracteres não numéricos
    if (!validarCNPJ(cnpj)) {
        alert("CNPJ inválido! Por favor, digite um CNPJ válido.");
        return false;
    }

    var senha = document.getElementById('senha').value;
    var confirmar_senha = document.getElementById('confirmar_senha').value;

    // Verifica se as senhas coincidem
    if (senha !== confirmar_senha) {
        alert('As senhas não coincidem.');
        return false;
    }

    // Verifica se a senha tem pelo menos 6 caracteres
    if (senha.length < 6) {
        alert('A senha deve ter pelo menos 6 caracteres.');
        return false;
    }

    var nome_da_loja = document.getElementById('nome_da_loja').value;
    if(!validarLoja(nome_da_loja)) {
        alert('O nome da loja não pode estar vazio!');
        return false;
    }

    var endereco = document.getElementById('endereco').value;
    if(!validarEndereco(endereco)) {
        alert('O Endereço deve ser preenchido!');
        return false;
    }

    var bairro = document.getElementById('bairro').value;
    if(!validarBairro(bairro)) {
        alert('O campo Bairro deve ser preenchido!');
        return false;
    }
    var cidade = document.getElementById('cidade').value;
    if(!validarCidade(cidade)) {
        alert('O campo Cidade deve ser preenchido!');
        return false
    }

    var uf = document.getElementById('uf').value
    if (!validarUF(uf)) {
      alert('Selecione uma das opções de Estado!')
      return false;
    }

    var email = document.getElementById('email').value; 
    if (!validarEmail(email)) {
      alert('E-mail inválido! Insira um e-mail válido.');
      return false;
    }

    var celular = document.getElementById('celular').value; 
    if (!validarCelular(celular)) {
      alert('Celular inválido! Insira um celular no formato (xx) xxxxx-xxxx.');
      return false;
    }

    if (!validarTipo_Loja()) {
      alert('Por favor, selecione um tipo de loja válido ou digite o tipo da sua loja no campo de ambições.');
      return false;
  }
  

      var ambicoes = document.getElementById('ambicoes').value;
      if (!validarAmbicoes(ambicoes)) {
        alert('O campo Ambições deve ser preenchido!');
        return false;
      }


    return true;
}

function mascaraCNPJ(input) {
  let cnpj = input.value.replace(/\D/g, ''); // Remove todos os caracteres não numéricos
  cnpj = cnpj.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5'); // Adiciona a formatação ao CNPJ
  input.value = cnpj; // Define o valor formatado de volta ao campo de entrada
}

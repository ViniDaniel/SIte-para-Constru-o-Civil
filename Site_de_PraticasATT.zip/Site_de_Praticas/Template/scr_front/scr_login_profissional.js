document.getElementById('loginFormProfissional').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita o envio do formulário padrão

    let cpf = document.getElementById('cpf_profissional').value;
    const senha = document.getElementById('senha_profissional').value;

    // Remover pontos e traços do CPF
    cpf = cpf.replace(/[.\-]/g, '');

    // Enviar dados para o servidor
    fetch('/login_colaborador', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ cpf, senha })
    })
    .then(response => response.json())
    .then(data => {
        console.log("Resposta do servidor:", data); // Log de depuração
        if (data.success) {
            // Armazena o nome do profissional no localStorage
            localStorage.setItem('profissionalNome', data.nome);
            // Redirecionar para a página home.html após login bem-sucedido
            window.location.href = "/home.html";
        } else {
            throw new Error(data.message || 'Credenciais inválidas');
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        alert('Credenciais inválidas');
    });
});

/*
Criado para vincular com o arquivo login_colaborador, fazer as autenticações no banco de dados e logar nosso usuario
localStorage serve para armazenar o nome do usuário e depois usá-lo para logar o mesmo
*/

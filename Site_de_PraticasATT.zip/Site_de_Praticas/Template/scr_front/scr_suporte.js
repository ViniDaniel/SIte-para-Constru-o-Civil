/*
function validarDenunciado(denunciado) verifica se a opção selecionada de quem está sendo denunciado é válida. Existem três opções válidas: 'denProfissional', 'denLojista' e 'denCliente'. A função retorna true se a opção estiver na lista, caso contrário, retorna false.
*/

function validarDenunciado(denunciado) {
  const denunciadoValidos = [
    'denProfissional', 'denLojista', 'denCliente'
]; 
  return denunciadoValidos.includes(denunciado);
}

function validarNome_Denunciado(Nome_Denunciado) {
  return Nome_Denunciado.trim() !== '';
}

function validarEndereco(enderecodenunciado) {
  return enderecodenunciado.trim() !== '';
}


function validarCidade(cidadedenunciado) {
  return cidadedenunciado.trim() !== '';
}

function validarUF(ufdenunciado) {
  const estadosValidos = [
    'AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN', 'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO'
]; 
  return estadosValidos.includes(ufdenunciado);
}

function validartipo_de_denuncia() {
  const tipo_de_denuncia = document.getElementById('tipo_de_denuncia').value; // Valor selecionado no campo de profissão
  const outraDenunciaInput = document.getElementById('outraDenuncia'); // Campo de texto para "outra profissão"

  if (tipo_de_denuncia === "" || tipo_de_denuncia === null) {
    return false; 
  }

  if (tipo_de_denuncia === 'outra' && outraDenunciaInput.value.trim() === '') {
    return false; 
  }

  return true;
}

function validarMotivo(motivo){
  return motivo.trim() !== '';
}


/*
function validarDenuncia() é a função principal que chama todas as funções de validação anteriores para garantir que todos os campos necessários foram preenchidos corretamente. Se qualquer uma das validações falhar, um alerta é exibido ao usuário e a função retorna false, interrompendo o processo de envio. Se todas as validações passarem, a função retorna true.
*/
function validarDenuncia() {

  var denunciado = document.getElementById('denunciado').value;
    if (!validarDenunciado(denunciado)) {
      alert('Selecione uma das opções de quem você deseja denunciar!');
      return false;
    }

    var Nome_Denunciado = document.getElementById('Nome_Denunciado').value;
    if (!validarNome_Denunciado(Nome_Denunciado)) {
      alert('Digite o nome de quem você deseja denuncir, tente escrever exatamente igual está no perfil desse usuário!');
      return false;
    }

    var enderecodenunciado = document.getElementById('enderecodenunciado').value;
    if (!validarEndereco(enderecodenunciado)) {
      alert('O campo de endereço precisa estar preenchido!');
      return false;
    }

    var cidadedenunciado = document.getElementById('cidadedenunciado').value;
    if (!validarCidade(cidadedenunciado)) {
      alert('O campo Cidade deve ser preenchido!');
      return false;
    }

    var ufdenunciado = document.getElementById('ufdenunciado').value
    if (!validarUF(ufdenunciado)) {
      alert('Selecione uma das opções de Estado!')
      return false;
    }

    if (!validartipo_de_denuncia()) {
      alert('Por favor, selecione o tipo de denuncia que deseja fazer ou digite a denuncia que quer fazer!'); 
      return false; 
    }

    var motivo = document.getElementById('motivo').value;
    if (!validarMotivo(motivo)) {
      alert('Digite a maior quantidade possível de informações para entendemos e avaliarmos a sua denuncia!');
      return false;
    }

    return true;

}



/*
Essa função valida o campo de dicas ou sugestões. Ela verifica se o campo não está vazio e se contém pelo menos 10 caracteres. Retorna false se alguma dessas condições não for atendida e true se ambas forem atendidas.
*/
function validarDica() {
  const dica = document.getElementById("Dicas").value;

 
  if (dica.trim() === "") {
      alert("A caixa de sugestões não pode estar vazia. Por favor, insira sua dica ou sugestão.");
      return false;
  }

 
  if (dica.trim().length < 10) {
      alert("Por favor, insira pelo menos 10 caracteres na sua sugestão.");
      return false;
  }

  return true;
}










function mostrarCampoOutra(selectElement) {
    const outraDenunciaInput = document.getElementById('outraDenuncia');
    outraDenunciaInput.style.display = (selectElement.value === 'outra') ? 'inline-block' : 'none';
    if (selectElement.value !== 'outra') {
      outraDenunciaInput.value = '';
    }
  }




  /*
  Quando o usuário tenta enviar uma denúncia ou sugestão, essas funções são chamadas para verificar se todas as informações foram preenchidas corretamente. Se algum campo estiver incorreto ou incompleto, o usuário recebe um alerta explicando o problema, e o envio é interrompido até que todas as informações estejam corretas.

  Este script ajuda a garantir que o usuário forneça todas as informações necessárias e em um formato válido antes de enviar uma denúncia ou sugestão, melhorando a qualidade dos dados recebidos e a experiência do usuário.
  */
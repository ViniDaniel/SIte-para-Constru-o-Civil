document.addEventListener('DOMContentLoaded', function () {
    var dropdowns = document.querySelectorAll('.dropdown');

    dropdowns.forEach(function (dropdown) {
        dropdown.addEventListener('click', function (event) {
            event.stopPropagation();
            var dropdownContent = this.querySelector('.dropdown-content');
            if (dropdownContent.style.display === 'block') {
                dropdownContent.style.display = 'none';
            } else {
                dropdownContent.style.display = 'block';
            }
        });
    });

    // Fechar o submenu se clicar fora dele
    document.addEventListener('click', function () {
        dropdowns.forEach(function (dropdown) {
            var dropdownContent = dropdown.querySelector('.dropdown-content');
            dropdownContent.style.display = 'none';
        });
    });
});

const modoNoturnoBtn = document.getElementById('modo-noturno');
let modoNoturnoAtivo = localStorage.getItem('modoNoturno') === 'true';

// Verifica e aplica o modo noturno ao carregar a página
if (modoNoturnoAtivo) {
    document.body.classList.add('modo-noturno');
    modoNoturnoBtn.style.backgroundImage = 'url(./Imagens/sun_icon.png)';
} else {
    modoNoturnoBtn.style.backgroundImage = 'url(./Imagens/moon_icon.png)';
}

modoNoturnoBtn.addEventListener('click', () => {
    modoNoturnoAtivo = !modoNoturnoAtivo;

    if (modoNoturnoAtivo) {
        modoNoturnoBtn.style.backgroundImage = 'url(./Imagens/sun_icon.png)';
        document.body.classList.add('modo-noturno');
    } else {
        modoNoturnoBtn.style.backgroundImage = 'url(./Imagens/moon_icon.png)';
        document.body.classList.remove('modo-noturno');
    }

    localStorage.setItem('modoNoturno', modoNoturnoAtivo);
});

document.addEventListener('DOMContentLoaded', function() {
    // Cliente
    const clienteNome = localStorage.getItem('clienteNome');
    if (clienteNome) {
        const clienteNomeElement = document.getElementById('cliente-nome');
        if (clienteNomeElement) {
            clienteNomeElement.textContent = clienteNome;
            clienteNomeElement.style.display = "inline"; // Exibir nome do cliente
        }
    }

    // Profissional
    const profissionalNome = localStorage.getItem('profissionalNome');
    if (profissionalNome) {
        const profissionalNomeElement = document.getElementById('profissional-nome');
        if (profissionalNomeElement) {
            profissionalNomeElement.textContent = profissionalNome;
            profissionalNomeElement.style.display = "inline"; // Exibir nome do profissional
        }
    }

    // Lojista
    const lojistaNome = localStorage.getItem('lojistaNome');
    if (lojistaNome) {
        const lojistaNomeElement = document.getElementById('lojista-nome');
        if (lojistaNomeElement) {
            lojistaNomeElement.textContent = lojistaNome;
            lojistaNomeElement.style.display = "inline"; // Exibir nome do lojista
        }
    }

    // Logout
    document.getElementById('logout-button').addEventListener('click', function() {
        localStorage.removeItem('clienteNome');
        localStorage.removeItem('profissionalNome');
        localStorage.removeItem('lojistaNome');
        window.location.href = "/home.html"; // Redirecionar para a página de login genérica
    });
});

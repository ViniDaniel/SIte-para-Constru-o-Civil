const express = require('express');
const app = express();
const bodyParser = require ('body-parser')
const path = require('path');
const cadastro_cliente_routes = require('./routes/cadastro_cliente');
const login_cliente_routes = require('./routes/login_cliente'); 
const cadastro_colaborador_routes = require('./routes/cadastro_colaborador');
const cadastro_lojista_routes = require('./routes/cadastro_lojista');
const login_colaborador_routes = require('./routes/login_colaborador');
const login_lojista_routes = require('./routes/login_lojista');


    app.use(bodyParser.urlencoded({extended: false})); //Configura o Body-Parser para processar dados de formulários.
    app.use(bodyParser.json()); //Configura o Body-Parser para processar dados em formato JSON.

    app.use(express.static(path.join(__dirname, 'Template'))); // Configura o Express para servir arquivos estáticos da pasta 'Template'.

    app.get('/', function(req, res) {
        res.sendFile(path.join(__dirname, 'Template', 'home.html')); //Define a rota raiz ('/') para servir o arquivo `home.html` da pasta 'Template'.
    });

    app.use('/', cadastro_cliente_routes); //Usa as rotas definidas no arquivo `cadastro_cliente_routes`.
    app.use('/', login_cliente_routes); //Usa as rotas definidas no arquivo `login_ccliente_routes`.
    app.use('/', cadastro_colaborador_routes); //Usa as rotas definidas no arquivo `cadastro_colaborador_routes`.
    app.use('/', cadastro_lojista_routes); //Usa as rotas definidas no arquivo `cadastro_lojista_routes`.
    app.use('/', login_colaborador_routes); //Usa as rotas definidas no arquivo `login_colaborador_routes`.
    app.use('/', login_lojista_routes); //Usa as rotas definidas no arquivo `login_lojista_routes`.

    
    app.listen(8081, function(){
        console.log('Servidor rodando na porta http://localhost:8081'); //Inicializa o servidor para ouvir na porta 8081 e exibe uma mensagem no console.
    });

    
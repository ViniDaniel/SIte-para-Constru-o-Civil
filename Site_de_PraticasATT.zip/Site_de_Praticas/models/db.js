const Sequelize = require('sequelize');
const sequelize = new Sequelize('easy_construl', 'root', 'Deny7457!vd', {
    host: 'localhost', 
    dialect: 'mysql' 
});




    module.exports = {
        Sequelize: Sequelize,
        sequelize: sequelize
    } 
    //a exportamos como uma rota, para fazemos uma ligação futuramente


/*Essa parte do código é dedicada para ser criada uma rota de exportação base para criações de banco de dados, principalmente
para a área de cadastro e afins, tornando o processo de encapsulamento e legibilidade dos arquivos melhor*/
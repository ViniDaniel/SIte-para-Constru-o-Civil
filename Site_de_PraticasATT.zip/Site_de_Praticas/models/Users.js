const db = require('./db') //puxa a rota base para a criação de banco de dados, sem precisar chamar tantas bibliotecas novamente



const Users = db.sequelize.define('clientes', {
    cpf: {
        type: db.Sequelize.STRING(15)
    },
    nome: {
        type: db.Sequelize.STRING(100)
    },
    cep: {
        type: db.Sequelize.STRING(8)
    },
    endereco: {
        type: db.Sequelize.STRING
    },
    numero_da_casa: {
        type: db.Sequelize.STRING
    },
    bairro: {
        type: db.Sequelize.STRING(30)
    },
    cidade: {
        type: db.Sequelize.STRING(30)
    },
    uf: {
        type: db.Sequelize.STRING(2)
    },
    complemento: {
        type: db.Sequelize.STRING
    },
    sexo: {
        type: db.Sequelize.STRING(30),
    },
    celular: {
        type: db.Sequelize.STRING(17)
    },
    email: {
        type: db.Sequelize.STRING
    },
    senha: {
        type: db.Sequelize.STRING
    }
});

module.exports = Users; //a exportamos como uma rota, para fazemos uma ligação futuramente

//Users.sync({force: true})


/*Linha 49 comentada, pois sempre que iniciar o app.js ele criara novamente o banco de dados, apagando o já antes criado
o ideal é apagar essa linha, mas como o site ainda está em construção, onde só geramos dados testes, ela facilita na hora de reconstruir os dados para novos teste*/


/*Área dedicada a criação do banco de dados do cliente, está diretamente ligada a área de cadastro_cliente, serve para ter melhor e maior fluidez, sem contar q facilita na criação e geração
de chaves a processos de administração de strings e afins*/
const db = require('./db'); //puxa a rota base para a criação de banco de dados, sem precisar chamar tantas bibliotecas novamente

const Lojista = db.sequelize.define('Lojista', {
    cnpj: {
        type: db.Sequelize.STRING(18)
    },
    inscricao_estadual :{
        type: db.Sequelize.STRING(18)
    },
    nome_da_loja: {
        type: db.Sequelize.STRING(100)
    },
    cep: {
        type: db.Sequelize.STRING(8)
    },
    endereco: {
        type: db.Sequelize.STRING
    },
    numero_da_loja: {
        type: db.Sequelize.STRING
    },
    bairro: {
        type: db.Sequelize.STRING(30)
    },
    cidade: {
        type: db.Sequelize.STRING(30)
    },
    uf: {
        type: db.Sequelize.STRING(2)
    },
    complemento: {
        type: db.Sequelize.STRING
    },
    celular: {
        type: db.Sequelize.STRING(17)
    },
    telefone: {
        type: db.Sequelize.STRING(17)
    },
    email: {
        type: db.Sequelize.STRING
    },
    tipo_loja: {
        type: db.Sequelize.STRING(50)
    },
    ambicoes: {
        type: db.Sequelize.STRING(500)
    },
    senha: {
        type: db.Sequelize.STRING
    }
})

module.exports = Lojista; //a exportamos como uma rota, para fazemos uma ligação futuramente

//Lojista.sync({force: true})


/*Linha 56 comentada, pois sempre que iniciar o app.js ele criara novamente o banco de dados, apagando o já antes criado
o ideal é apagar essa linha, mas como o site ainda está em construção, onde só geramos dados testes, ela facilita na hora de reconstruir os dados para novos teste*/


/*Área dedicada a criação do banco de dados do lojista, está diretamente ligada a área de cadastro_lojista, serve para ter melho e maior fluidez, sem contar q facilita na criação e geração
de chaves a processos de administração de strings e afins*/
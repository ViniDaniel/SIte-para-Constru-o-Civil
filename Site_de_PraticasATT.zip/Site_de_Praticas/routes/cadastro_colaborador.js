const express = require('express');//chama a principla biblioteca do node.js, para fazermos as criações e funções para o site
const bcrypt = require('bcrypt'); //essencial para mantermos a privacidade e segurança do usuario. mais sobre ele no arquivo de explicação
const Profissionais = require('../models/Profissionais'); //chama o arquivo Profissionais.js, facilitando a criação do banco de dados e o tornando mais legivel
const router = express.Router(); //é aqui q indicamos a nossa rota pra ser feita a ligação e criação no banco de dados


//abaixo chamamos o router para indicar de onde está vindo as informações para o banco de dados, o "body" de forma literal é o corpo do script do front_end, servindo também para fazer a ligação
router.post('/cadastro_colaborador', async function(req, res) {
    const {
        cpf,
        nome,
        cep,
        endereco,
        numero_da_casa,
        bairro,
        cidade,
        uf,
        complemento,
        sexo,
        celular,
        email,
        profissao,
        formacao_superior,
        formacao_tecnica,
        ambicoes,
        senha,
        confirmar_senha
    } = req.body;


//abaixo confirmamos as senha novamente por segurança, e depois fazemos o processo do bcrypt para conseguirmos aumentar a segurança do nosso usuario
    if (senha !== confirmar_senha) {
        return res.status(400).json({ success: false, message: 'As senhas não coincidem!' });
    }

    try {
        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(senha, saltRounds);

        await Profissionais.create({
            cpf,
            nome,
            cep,
            endereco,
            numero_da_casa,
            bairro,
            cidade,
            uf,
            complemento,
            sexo,
            celular,
            email,
            profissao,
            formacao_superior,
            formacao_tecnica,
            ambicoes,
            senha: hashedPassword
        });

        res.json({ success: true, message: 'Usuário cadastrado com sucesso!' });
    } catch (erro) {
        res.status(500).json({ success: false, message: 'Erro ao cadastrar usuário!', error: erro });
    }
});



module.exports = router; //a exportamos como uma rota, para fazemos uma ligação futuramente





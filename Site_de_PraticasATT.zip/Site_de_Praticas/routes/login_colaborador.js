const express = require('express'); //chama a principla biblioteca do node.js, para fazermos as criações e funções para o site
const router = express.Router(); //é aqui q indicamos a nossa rota pra ser feita a ligação e criação no banco de dados. mais sobre ele no arquivo de explicação
const bcrypt = require('bcrypt');  //essencial para mantermos a privacidade e segurança do usuario. mais sobre ele no arquivo de explicação
const Profissionais = require('../models/Profissionais'); //chama o arquivo Profissionais para fazermos a verificações de usuario no banco de dados e o logarmos

/*abaixo chamamos o router para indicar de onde está vindo as informações para o banco de dados, depois verifica a existencia da senha e cpf para fazer 
o login do profissional */
router.post('/login_colaborador', async function(req, res) {
    const { cpf, senha } = req.body;

    try {
        const user = await Profissionais.findOne({ where: { cpf: cpf } });

        if (user) {
            const isMatch = await bcrypt.compare(senha, user.senha);
            if (isMatch) {
                res.json({ success: true, nome: user.nome });
            } else {
                res.status(401).json({ success: false, message: 'CPF ou senha incorretos!' });
            }
        } else {
            res.status(401).json({ success: false, message: 'CPF ou senha incorretos!' });
        }
    } catch (error) {
        console.error("Erro ao tentar fazer login:", error);
        res.status(500).json({ success: false, message: 'Erro ao tentar fazer login!' });
    }
});

module.exports = router; //a exportamos como uma rota, para fazemos uma ligação futuramente

const express = require('express'); //chama a principla biblioteca do node.js, para fazermos as criações e funções para o site
const router = express.Router(); //é aqui q indicamos a nossa rota pra ser feita a ligação e criação no banco de dados. mais sobre ele no arquivo de explicação
const bcrypt = require('bcrypt'); //essencial para mantermos a privacidade e segurança do usuario. mais sobre ele no arquivo de explicação
const Lojista = require('../models/Lojista'); //chama o arquivo lojista para fazermos a verificações de usuario no banco de dados e o logarmos

/*abaixo chamamos o router para indicar de onde está vindo as informações para o banco de dados, depois verifica a existencia da senha e cnpj para fazer 
o login do lojista */
router.post('/login_lojista', async function(req, res) {
    const { cnpj, senha } = req.body;

    try {
        const user = await Lojista.findOne({ where: { cnpj: cnpj } });

        if (user) {
            const isMatch = await bcrypt.compare(senha, user.senha);
            if (isMatch) {
                res.json({ success: true, nome: user.nome_da_loja }); 
            } else {
                res.status(401).json({ success: false, message: 'CNPJ ou senha incorretos!' });
            }
        } else {
            res.status(401).json({ success: false, message: 'CNPJ ou senha incorretos!' });
        }
    } catch (error) {
        console.error("Erro ao tentar fazer login:", error);
        res.status(500).json({ success: false, message: 'Erro ao tentar fazer login!' });
    }
});


module.exports = router; //a exportamos como uma rota, para fazemos uma ligação futuramente

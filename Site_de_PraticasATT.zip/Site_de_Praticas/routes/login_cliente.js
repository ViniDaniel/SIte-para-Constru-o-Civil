const express = require('express'); //chama a principla biblioteca do node.js, para fazermos as criações e funções para o site.  mais sobre ele no arquivo de explicação
const router = express.Router(); //é aqui q indicamos a nossa rota pra ser feita a ligação e criação no banco de dados. mais sobre ele no arquivo de explicação
const bcrypt = require('bcrypt'); //essencial para mantermos a privacidade e segurança do usuario. mais sobre ele no arquivo de explicação
const Users = require('../models/Users'); //chama o arquivo Users para fazermos a verificações de usuario no banco de dados e o logarmos

/*abaixo chamamos o router para indicar de onde está vindo as informações para o banco de dados, depois verifica a existencia da senha e cpf para fazer 
o login do cliente */
router.post('/login_cliente', async function(req, res) {
    const { cpf, senha } = req.body;

    try {
        const user = await Users.findOne({ where: { cpf: cpf } });

        if (user) {
            const isMatch = await bcrypt.compare(senha, user.senha);
            if (isMatch) {
                res.json({ success: true, nome: user.nome });
            } else {
                res.status(401).json({ success: false, message: 'CPF ou senha incorretos!' });
            }
        } else {
            res.status(401).json({ success: false, message: 'CPF ou senha incorretos!' });
        }
    } catch (error) {
        console.error("Erro ao tentar fazer login:", error);
        res.status(500).json({ success: false, message: 'Erro ao tentar fazer login!' });
    }
});

module.exports = router; //a exportamos como uma rota, para fazemos uma ligação futuramente

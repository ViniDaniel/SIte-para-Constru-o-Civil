
const express = require('express');//chama a principla biblioteca do node.js, para fazermos as criações e funções para o site
const bcrypt = require('bcrypt'); //essencial para mantermos a privacidade e segurança do usuario. mais sobre ele no arquivo de explicação
const Lojista = require('../models/Lojista'); //chama o arquivo Lojista.js, facilitando a criação do banco de dados e o tornando mais legivel
const router = express.Router(); //é aqui q indicamos a nossa rota pra ser feita a ligação e criação no banco de dados


//abaixo chamamos o router para indicar de onde está vindo as informações para o banco de dados, o "body" de forma literal é o corpo do script do front_end, servindo também para fazer a ligação
router.post('/cadastro_lojista', async function(req, res) {
    const {
        cnpj,
        inscricao_estadual,
        nome_da_loja,
        cep,
        endereco,
        numero_da_loja,
        bairro,
        cidade,
        uf,
        complemento,
        celular,
        telefone,
        email,
        tipo_loja,
        ambicoes,
        senha,
        confirmar_senha
    } = req.body;


    //abaixo confirmamos as senha novamente por segurança, e depois fazemos o processo do bcrypt para conseguirmos aumentar a segurança do nosso usuario
    if (senha !== confirmar_senha) {
        return res.status(400).json({ success: false, message: 'As senhas não coincidem!' });
    }

    try {
        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(senha, saltRounds);

        await Lojista.create({
            cnpj,
            inscricao_estadual,
            nome_da_loja,
            cep,
            endereco,
            numero_da_loja,
            bairro,
            cidade,
            uf,
            complemento,
            celular,
            telefone,
            email,
            tipo_loja,
            ambicoes,
            senha: hashedPassword
        });

        res.json({ success: true, message: 'Lojista cadastrado com sucesso!' });
    } catch (erro) {
        res.status(500).json({ success: false, message: 'Erro ao cadastrar o lojista!', error: erro });
    }
});



module.exports = router; //a exportamos como uma rota, para fazemos uma ligação futuramente


